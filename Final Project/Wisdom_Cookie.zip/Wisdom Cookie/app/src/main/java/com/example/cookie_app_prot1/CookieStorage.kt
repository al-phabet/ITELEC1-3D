package com.example.cookie_app_prot1

import android.content.Context
import androidx.core.content.edit

object CookieStorage {

    private const val PREFS_NAME = "cookie_quotes"
    private const val KEY_QUOTES = "quotes"
    private const val MAX_QUOTES = 50 // Maximum number of quotes to store

    // Save a new quote
    fun saveQuote(context: Context, quote: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentSet = prefs.getStringSet(KEY_QUOTES, emptySet())?.toMutableList() ?: mutableListOf()

        currentSet.remove(quote)

        val currentList = currentSet.toMutableList()
        currentList.add(0, quote) // Add newest at the top

        val trimmedList = if (currentList.size > MAX_QUOTES) {
            currentList.subList(0, MAX_QUOTES)
        } else {
            currentList
        }

        prefs.edit { putStringSet(KEY_QUOTES, trimmedList.toSet()) }
    }

    // Get all saved quotes (newest first)
    fun getAllQuotes(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = prefs.getStringSet(KEY_QUOTES, emptySet())?.toList() ?: emptyList()
        // Sort by insertion order: newest first (we saved newest first)
        return current.reversed()
    }

    // Unsave specific quote
    fun removeQuote(context: Context, quote: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = prefs.getStringSet(KEY_QUOTES, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (current.remove(quote)) {
            prefs.edit { putStringSet(KEY_QUOTES, current) }
        }
    }

    // Clear all saved quotes
    fun clearQuotes(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { remove(KEY_QUOTES) }
    }
}
