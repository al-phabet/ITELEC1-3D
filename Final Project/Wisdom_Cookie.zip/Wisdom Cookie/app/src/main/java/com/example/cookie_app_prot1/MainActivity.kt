package com.example.cookie_app_prot1

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageSwitcher
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private val cookieImages = arrayOf(
        R.drawable.choco_1,
        R.drawable.cookie_1,
        R.drawable.donut_1,
        R.drawable.ginger_1,
        R.drawable.pretzel_1
    )

    private val cookieNames = arrayOf(
        "Chocolate Chip",
        "Sugar Cookie",
        "Donut Cookie",
        "Ginger Cookie",
        "Pretzel Cookie"
    )

    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        btnMenu.setOnClickListener {
            startActivity(Intent(this, SettingsMenuActivity::class.java))
        }

        // Ask notification permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        }

        // UI elements
        val imageSwitcher = findViewById<ImageSwitcher>(R.id.imageSwitcher)
        val txtCookieName = findViewById<TextView>(R.id.txtCookieName)
        val btnNext = findViewById<Button>(R.id.btnNext)
        val btnPrev = findViewById<Button>(R.id.btnPrev)
        val btnProceed = findViewById<Button>(R.id.btnProceed)
        val btnInfo = findViewById<ImageButton>(R.id.btnInfo)

        // ImageSwitcher
        imageSwitcher.setFactory {
            ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            }
        }
        imageSwitcher.setInAnimation(this, android.R.anim.fade_in)
        imageSwitcher.setOutAnimation(this, android.R.anim.fade_out)

        fun updateCookie() {
            imageSwitcher.setImageResource(cookieImages[currentIndex])
            txtCookieName.text = cookieNames[currentIndex]
        }

        updateCookie()

        btnNext.setOnClickListener {
            currentIndex = (currentIndex + 1) % cookieImages.size
            updateCookie()
        }

        btnPrev.setOnClickListener {
            currentIndex =
                if (currentIndex == 0) cookieImages.size - 1 else currentIndex - 1
            updateCookie()
        }

        btnProceed.setOnClickListener {
            val intent = Intent(this, QuoteActivity::class.java)
            intent.putExtra("COOKIE_TYPE", cookieNames[currentIndex])
            startActivity(intent)
        }

        btnInfo.setOnClickListener {
            showInstructionPopup()
        }
    }

    // Menu settings
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                startActivity(Intent(this, SettingsMenuActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showInstructionPopup() {
        val dialog = android.app.Dialog(this)
        dialog.setContentView(R.layout.popup_instruction)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)

        val btnClose = dialog.findViewById<ImageButton>(R.id.btnClose)
        btnClose.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }
}
