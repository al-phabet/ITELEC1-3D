package com.example.cookie_app_prot1

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CookieJarActivity : AppCompatActivity() {

    private lateinit var cookieRecycler: RecyclerView
    private lateinit var cookieAdapter: CookieAdapter
    private var savedQuotes = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cookie_jar)

        // Load saved quotes
        savedQuotes = CookieStorage.getAllQuotes(this).toMutableList()

        cookieRecycler = findViewById(R.id.cookieRecycler)
        cookieRecycler.layoutManager = LinearLayoutManager(this)

        cookieAdapter = CookieAdapter(savedQuotes) { quote ->
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("quote", quote)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
        }

        cookieRecycler.adapter = cookieAdapter

        // Optional: Clear all button
        findViewById<Button>(R.id.clearAllBtn)?.setOnClickListener {
            CookieStorage.clearQuotes(this)
            savedQuotes.clear()
            cookieAdapter.notifyDataSetChanged()
            Toast.makeText(this, "All quotes cleared!", Toast.LENGTH_SHORT).show()
        }
    }
}
