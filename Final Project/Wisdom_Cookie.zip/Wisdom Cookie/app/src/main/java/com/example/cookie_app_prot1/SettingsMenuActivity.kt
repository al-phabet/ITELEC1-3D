package com.example.cookie_app_prot1


import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class SettingsMenuActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings_menu)

        val notifSettings = findViewById<LinearLayout>(R.id.optionNotification)
        val aboutSettings = findViewById<LinearLayout>(R.id.optionAbout)

        notifSettings.setOnClickListener {
            startActivity(Intent(this, SettingsNotifActivity::class.java))
        }

        aboutSettings.setOnClickListener {
            startActivity(Intent(this, SettingsAboutActivity::class.java))
        }
    }
}
