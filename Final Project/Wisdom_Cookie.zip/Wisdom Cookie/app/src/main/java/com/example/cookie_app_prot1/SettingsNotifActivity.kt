package com.example.cookie_app_prot1

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import java.util.*

class SettingsNotifActivity : AppCompatActivity() {

    private lateinit var btnPickTime: Button
    private lateinit var txtSelectedTime: TextView
    private lateinit var btnSave: Button

    private lateinit var dayViews: List<TextView>

    private var selectedHour = 9
    private var selectedMinute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings_notif)

        // UI
        btnPickTime = findViewById(R.id.btnPickTime)
        txtSelectedTime = findViewById(R.id.txtSelectedTime)
        btnSave = findViewById(R.id.btnSaveSettings)

        // Day cards
        val sun = findViewById<TextView>(R.id.sun)
        val mon = findViewById<TextView>(R.id.mon)
        val tue = findViewById<TextView>(R.id.tue)
        val wed = findViewById<TextView>(R.id.wed)
        val thu = findViewById<TextView>(R.id.thu)
        val fri = findViewById<TextView>(R.id.fri)
        val sat = findViewById<TextView>(R.id.sat)

        dayViews = listOf(sun, mon, tue, wed, thu, fri, sat)

        // Load saved settings
        loadSettings()

        // Day card click toggle
        dayViews.forEachIndexed { index, day ->
            day.setOnClickListener {
                day.isSelected = !day.isSelected
                updateDayBackground(day)
                saveDaySelection(index, day.isSelected)
            }
        }

        // Time picker
        btnPickTime.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    selectedHour = hour
                    selectedMinute = minute
                    txtSelectedTime.text = formatTime(hour, minute)
                },
                selectedHour,
                selectedMinute,
                false // 12-hour format
            ).show()
        }

        // Save button
        btnSave.setOnClickListener {
            saveTime()
            scheduleNotifications()
            Toast.makeText(this, "Settings Saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun formatTime(hour24: Int, minute: Int): String {
        val amPm = if (hour24 >= 12) "PM" else "AM"
        val hour12 = if (hour24 % 12 == 0) 12 else hour24 % 12
        return "%02d:%02d %s".format(hour12, minute, amPm)
    }


    private fun loadSettings() {
        val prefs = getSharedPreferences("notif_settings", Context.MODE_PRIVATE)
        selectedHour = prefs.getInt("hour", 9)
        selectedMinute = prefs.getInt("minute", 0)
        txtSelectedTime.text = formatTime(selectedHour, selectedMinute)

        val dayKeys = listOf("sun","mon","tue","wed","thu","fri","sat")
        dayViews.forEachIndexed { index, textView ->
            val isSelected = prefs.getBoolean(dayKeys[index], false)
            textView.isSelected = isSelected
            updateDayBackground(textView)
        }
    }

    // Save time
    private fun saveTime() {
        val prefs = getSharedPreferences("notif_settings", Context.MODE_PRIVATE)
        prefs.edit {
            putInt("hour", selectedHour)
            putInt("minute", selectedMinute)
        }
    }

    // Save day
    private fun saveDaySelection(index: Int, selected: Boolean) {
        val prefs = getSharedPreferences("notif_settings", Context.MODE_PRIVATE)
        val dayKeys = listOf("sun","mon","tue","wed","thu","fri","sat")
        prefs.edit { putBoolean(dayKeys[index], selected) }
    }

    // Update day card background and text color
    private fun updateDayBackground(day: TextView) {
        if (day.isSelected) {
            day.setBackgroundResource(R.drawable.day_card_selected)
            day.setTextColor(resources.getColor(R.color.white))
        } else {
            day.setBackgroundResource(R.drawable.day_card_unselected)
            day.setTextColor(resources.getColor(R.color.dark_blue))
        }
    }

    // Schedule notifications
    private fun scheduleNotifications() {
        val prefs = getSharedPreferences("notif_settings", Context.MODE_PRIVATE)
        val hour = prefs.getInt("hour", 9)
        val minute = prefs.getInt("minute", 0)

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val dayKeys = listOf("sun","mon","tue","wed","thu","fri","sat")

        for (i in 0..6) {
            if (prefs.getBoolean(dayKeys[i], false)) {
                val intent = Intent(this, NotificationReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(
                    this, i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val calendar = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_WEEK, i + 1) // Sunday=1
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }

                if (calendar.before(Calendar.getInstance())) {
                    calendar.add(Calendar.WEEK_OF_YEAR, 1)
                }

                alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    AlarmManager.INTERVAL_DAY * 7,
                    pendingIntent
                )
            }
        }
    }
}
