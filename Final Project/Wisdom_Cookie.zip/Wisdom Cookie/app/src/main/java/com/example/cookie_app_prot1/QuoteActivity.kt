package com.example.cookie_app_prot1

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cookie_app_prot1.databinding.QuoteActivityBinding
class QuoteActivity : AppCompatActivity() {

    private lateinit var binding: QuoteActivityBinding
    private var isCookieCracked = false
    private var currentQuote: String? = null
    private var isQuoteSaved = false


    //Different quotes for each cookie type
    private val quotesMap = mapOf(
        "Chocolate Chip" to listOf(
            "Life is sweet, just like a chocolate chip cookie!",
            "Happiness is homemade.",
            "Chocolate heals everything.",
            "Keep your face toward the sunshine, and shadows will fall behind you.",
            "Happiness is found in the little things.",
            "Smile, it’s free therapy.",
            "Choose joy every single day.",
            "A happy heart makes a glowing life.",
            "Spread kindness like confetti.",
            "Find the silver lining in every cloud.",
            "Laugh often, love much, live fully.",
            "Let your smile change the world.",
            "Happiness grows when shared.",
            "Gratitude turns what we have into enough.",
            "Joy is not in things, it’s in you.",
            "Positive thoughts, positive life.",
            "Be a rainbow in someone’s cloud.",
            "Every day is a fresh start.",
            "Fill your cup with positivity.",
            "Small moments, big happiness.",
            "Shine bright, the world needs your light.",
            "Focus on what you can control and let go of the rest.",
            "Life is better when you laugh.",
            "Choose optimism—it’s contagious.",
            "A cheerful heart brings wellness.",
            "Collect moments, not things.",
            "Be happy for this moment—it’s your life.",
            "Don’t wait for perfect, find happiness now.",
            "Joy multiplies when you share it.",
            "Let gratitude guide your steps.",
            "Positivity is a superpower.",
            "The best is yet to come.",
            "Happiness is a journey, not a destination.",
            "Find beauty in ordinary things.",
            "Keep hope alive in your heart.",
            "Celebrate small victories.",
            "Life is tough, but so are you.",
            "Surround yourself with positivity.",
            "Every sunrise is a new chance.",
            "Let your heart be light.",
            "Laughter heals.",
            "Choose love over fear.",
            "Smile—it costs nothing.",
            "Seek joy in unexpected places.",
            "A grateful heart is a happy heart.",
            "Happiness starts within.",
            "Life is sweeter when you smile.",
            "Positive vibes attract positive life.",
            "Let happiness be your compass.",
            "Dance like nobody’s watching.",
            "Shine your light wherever you go."
        ),

        //Sugar Cookie – Self-Improvement & Growth
        "Sugar Cookie" to listOf(
            "Simple joys are the sweetest.",
            "Life is sugar and spice.",
            "A little sweetness goes a long way.",
            "Don’t go through life, grow through life.",
            "Strive to be better than you were yesterday.",
            "Growth begins at the end of your comfort zone.",
            "Every challenge is a lesson in disguise.",
            "Small steps lead to big change.",
            "The best project you’ll ever work on is yourself.",
            "Learn something new every day.",
            "Progress, not perfection.",
            "Your potential is endless.",
            "Fail forward; learn, then move on.",
            "Change starts with awareness.",
            "Plant seeds today for a stronger tomorrow.",
            "Be curious, always.", "Growth is uncomfortable but worth it.",
            "Invest in yourself first.",
            "Keep learning, keep evolving.",
            "You are capable of more than you know.",
            "Step by step, you will reach your goal.",
            "Personal growth is a lifelong journey.",
            "Embrace challenges—they shape you.",
            "Self-reflection leads to clarity.",
            "Mistakes are stepping stones to wisdom.",
            "Your comfort zone is a beautiful place, but nothing grows there.",
            "Transform yourself through action.",
            "Believe in your ability to grow.",
            "Be patient with your progress.",
            "Seek knowledge, not approval.",
            "Dare to evolve.",
            "Strength grows in the struggle.",
            "Keep stretching your limits.",
            "Each day is a chance to improve.",
            "Cultivate habits that inspire growth.",
            "Be the best version of yourself today.",
            "Life’s lessons are everywhere—pay attention.",
            "Growth requires courage.",
            "Focus on your journey, not the destination.",
            "You are your only competition.",
            "Embrace change—it’s part of growth.",
            "Learn to rise stronger after a fall.",
            "Your mindset shapes your future.",
            "Knowledge is power, but applied knowledge is freedom.",
            "Commit to lifelong learning.",
            "Adaptability is the key to growth.",
            "Be intentional with your self-improvement.",
            "Every step forward counts.",
            "Challenge yourself daily.",
            "Invest in habits, not excuses.",
            "Growth takes persistence and patience.",
            "Reflection fuels progress.",
            "Keep moving forward—small gains add up."
        ),

        //Donut Cookie – Courage & Bravery
        "Donut Cookie" to listOf(
            "Donuts are happiness in a circle!",
            "Sprinkle joy wherever you go.",
            "Sweet moments make life tasty.",
            "Do one thing every day that scares you.",
            "Courage doesn’t mean you aren’t afraid; it means you act anyway.",
            "Fortune favors the bold.",
            "Be brave enough to start.",
            "Step into the unknown with confidence.",
            "Fear is temporary, regret is forever.",
            "Bold actions create bold results.",
            "Dare to be different.",
            "Bravery begins with a single step.",
            "Face your fears—they’re usually smaller than they appear.",
            "Courage is a habit, not a feeling.",
            "Take the risk or lose the chance.",
            "Life shrinks or expands in proportion to your courage.",
            "Stand up, even when it’s hard.",
            "Brave hearts inspire others.",
            "Risk brings reward.",
            "Don’t let fear decide your future.",
            "Courage is contagious—spread it.",
            "Adventure begins where comfort ends.",
            "Be bold, or go home.",
            "Your fear is not your enemy; inaction is.",
            "Leap, and the net will appear.",
            "Fear tests, courage conquers.",
            "Strength grows in moments of fear.",
            "Take chances—they often lead to growth.",
            "Boldness opens doors others cannot see.",
            "Courage is doing the right thing, even if alone.",
            "Face challenges head-on.",
            "Bravery is not the absence of fear,but action despite it.",
            "Dare greatly, live fully.",
            "Small acts of courage matter.",
            "Challenge breeds courage.",
            "Risk is the bridge between dreams and reality.",
            "Stand firm when it matters most.",
            "Courage transforms obstacles into opportunities.",
            "Fear fades when action begins.",
            "Be fearless in pursuit of your goals.",
            "Life rewards the brave.",
            "Step forward, even if trembling.",
            "Courage is forged in adversity.",
            "Don’t wait for permission—act now.",
            "Bold decisions shape destiny.",
            "Every brave choice strengthens you.",
            "Act with heart, even if scared.",
            "Fear is a signal to grow, not to stop.",
            "Face the storm to see the rainbow.",
            "Brave souls leave lasting footprints.",
            "Courage is the key to freedom.",
            "Take the first step; the path will follow.",
            "Be brave, the world needs your boldness."
        ),

        //Gingerbread Cookie – Wisdom & Knowledge
        "Ginger Cookie" to listOf(
            "Ginger cookies spice up life!",
            "Warm hearts like warm cookies.",
            "Life’s best with a little spice.",
            "Knowing yourself is the beginning of all wisdom.",
            "The only true wisdom is in knowing you know nothing.",
            "Knowledge speaks, but wisdom listens.",
            "Wisdom begins in wonder.",
            "Listen more than you speak.",
            "Learn from the past, live in the present, plan for the future.",
            "The wise man learns more from his failures than the fool from his success.",
            "Patience is the companion of wisdom.",
            "Think before you speak.",
            "Experience is the teacher of all things.",
            "Seek first to understand, then to be understood.",
            "A wise person knows when to act and when to wait.",
            "Knowledge without practice is meaningless.",
            "True wisdom is knowing when to say nothing.",
            "Life is a teacher; wisdom is its lesson.",
            "Observe before you judge.",
            "Wisdom is the reward of experience.",
            "Silence is sometimes the best answer.",
            "The wise adapt; the foolish resist.",
            "Learn to see things from every angle.",
            "Wise hearts hear beyond words.",
            "Knowledge is a treasure, but practice is the key to it.",
            "Reflect before reacting.", "A wise mind embraces change.",
            "Listen to understand, not to reply.",
            "Seek knowledge, but value wisdom.",
            "Life becomes easier with insight.",
            "Awareness precedes understanding.",
            "Wisdom grows when shared.",
            "Think deeply, act wisely.",
            "The wise value time above all.",
            "Truth is often simple, but discernment is needed.",
            "Learn more than you speak.",
            "Wisdom is knowing what matters most.",
            "Experience teaches, but reflection reveals.",
            "Patience and reflection are paths to wisdom.",
            "The eyes see, but the mind understands.",
            "Knowledge gives answers, wisdom asks the right questions.",
            "Learn from everyone, but trust your own judgment.",
            "A calm mind is a wise mind.",
            "Insight comes from quiet observation.",
            "Wisdom is guiding others, not controlling them.",
            "Knowledge is powerful, but wisdom is enlightening.",
            "Choose your words as carefully as your actions.",
            "Understanding bridges differences.",
            "Seek clarity, not just information.",
            "Every mistake carries a lesson.",
            "True wisdom listens to the voice within.",
            "Think long-term, act short-term.",
            "A wise person acts with both heart and mind."
        ),

        //Pretzel Cookie – Perseverance & Hard Work
        "Pretzel Cookie" to listOf(
            "Twist your worries away.",
            "Life is better with a little crunch.",
            "Salted moments are golden.",
            "Fall seven times and stand up eight.",
            "Hard work beats talent when talent doesn’t work hard.",
            "Success is the sum of small efforts repeated daily.",
            "Keep going; you’re getting there.",
            "The harder the struggle, the greater the reward.",
            "Don’t stop when you’re tired; stop when you’re done.",
            "Perseverance is the key to success.",
            "Great things take time.",
            "Hustle in silence, let success make the noise.",
            "The only way out is through.", "Push yourself, no one else is going to do it for you.",
            "Success is built on consistency.",
            "Your effort today creates your tomorrow.",
            "Keep climbing; the view is worth it.",
            "Determination turns obstacles into opportunities.",
            "Endurance is strength.",
            "One step at a time leads to victory.",
            "Stay committed to your goals.",
            "Don’t quit; you are stronger than you think.",
            "Sweat is the price of success.",
            "Strive for progress, not perfection.",
            "Every effort counts.",
            "Success favors the persistent.",
            "Keep your eyes on the goal.",
            "Hard work compounds over time.",
            "Never give up on something you really want.",
            "Patience and persistence overcome obstacles.",
            "Consistency is your secret weapon.",
            "Work hard in silence, let results speak.",
            "Persistence breaks down barriers.",
            "Effort today shapes your future.",
            "Don’t wait for opportunity; create it.",
            "Difficult roads lead to beautiful destinations.",
            "Keep moving forward, even slowly.",
            "Your grind will pay off.",
            "Success is earned, not given.",
            "Every step forward is progress.",
            "Strength grows through struggle.",
            "Stay the course, no matter the challenge.",
            "Great achievements require hard work.",
            "Don’t be afraid of effort.",
            "Work until you no longer have to introduce yourself.",
            "Perseverance conquers resistance.",
            "Hard work is the bridge between dreams and reality.",
            "Keep sowing; harvest comes in time.",
            "Challenges are opportunities in disguise.",
            "Work patiently and persistently.",
            "The journey is tough, but so are you.",
            "Grind now, shine later.",
            "Success belongs to those who endure."
        )
    )


    private val cookieImages = mapOf(
        "Chocolate Chip" to R.drawable.choco_1,
        "Sugar Cookie" to R.drawable.cookie_1,
        "Donut Cookie" to R.drawable.donut_1,
        "Ginger Cookie" to R.drawable.ginger_1,
        "Pretzel Cookie" to R.drawable.pretzel_1
    )

    private val crackAnimations = mapOf(
        "Chocolate Chip" to R.drawable.choco_anim,
        "Sugar Cookie" to R.drawable.cookie_anim,
        "Donut Cookie" to R.drawable.donut_anim,
        "Ginger Cookie" to R.drawable.ginger_anim,
        "Pretzel Cookie" to R.drawable.pretzel_anim
    )

    private val smallCookieImages = mapOf(
        "Chocolate Chip" to R.drawable.choco_small,
        "Sugar Cookie" to R.drawable.cookie_small,
        "Donut Cookie" to R.drawable.donut_small,
        "Ginger Cookie" to R.drawable.ginger_small,
        "Pretzel Cookie" to R.drawable.pretzel_small
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = QuoteActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val selectedCookie = intent.getStringExtra("COOKIE_TYPE") ?: "Chocolate Chip"
        val cookieImageRes = cookieImages[selectedCookie] ?: R.drawable.choco_1
        val cookieSmallRes = smallCookieImages[selectedCookie] ?: R.drawable.choco_small

        val quotes = quotesMap[selectedCookie] ?: quotesMap["Chocolate Chip"]!!

        binding.cookieImage.setImageResource(cookieImageRes)
        binding.savedCookieImage.setImageResource(cookieSmallRes)

        binding.randomMessage.text = "You chose: $selectedCookie"
        isQuoteSaved = false

        //  COOKIE TAP
        binding.cookieImage.setOnClickListener {
            if (isCookieCracked) return@setOnClickListener
            isCookieCracked = true

            val crackAnimRes = crackAnimations[selectedCookie]
            crackAnimRes?.let { animRes ->

                binding.cookieImage.setImageResource(animRes)
                val animation = binding.cookieImage.drawable as AnimationDrawable
                animation.start()

                // compute duration
                var total = 0
                for (i in 0 until animation.numberOfFrames) {
                    total += animation.getDuration(i)
                }

                // Show quote
                currentQuote = quotes.random()
                binding.randomMessage.text = currentQuote
                isQuoteSaved = false
                binding.heartButton.setImageResource(R.drawable.ic_heart)

                // reset after crack animation
                binding.cookieImage.postDelayed({
                    binding.cookieImage.setImageResource(cookieImageRes)
                    isCookieCracked = false
                }, total.toLong())
            }
        }

        //  HEART BUTTON SAVE
        binding.heartButton.setOnClickListener {
            currentQuote?.let { quote ->

                if (!isQuoteSaved) {
                    // SAVE
                    CookieStorage.saveQuote(this, quote)
                    Toast.makeText(this, "Quote saved!", Toast.LENGTH_SHORT).show()
                    binding.heartButton.setImageResource(R.drawable.ic_heart_filled)
                    isQuoteSaved = true

                    // 🔥 Animate small cookie into jar
                    animateCookieToJar(selectedCookie)

                } else {
                    // UNSAVE
                    CookieStorage.removeQuote(this, quote)
                    Toast.makeText(this, "Quote removed!", Toast.LENGTH_SHORT).show()
                    binding.heartButton.setImageResource(R.drawable.ic_heart)
                    isQuoteSaved = false
                }

            } ?: Toast.makeText(this, "Crack a cookie first!", Toast.LENGTH_SHORT).show()
        }

        //  COOKIE JAR CLICK
        binding.cookieJarImage.setOnClickListener {
            startActivity(Intent(this, CookieJarActivity::class.java))
        }
    }

    // SMALL COOKIE ANIMATION
    private fun animateCookieToJar(cookieType: String) {

        val smallCookie = binding.savedCookieImage
        val mainCookie = binding.cookieImage
        val cookieJar = binding.cookieJarImage

        // Set correct small cookie again before animation
        val smallRes = smallCookieImages[cookieType] ?: R.drawable.choco_small
        smallCookie.setImageResource(smallRes)

        smallCookie.visibility = View.VISIBLE

        // starting position – center of main cookie
        val startX = mainCookie.x + mainCookie.width / 2f - smallCookie.width / 2f
        val startY = mainCookie.y + mainCookie.height / 2f - smallCookie.height / 2f

        // end → cookie jar center
        val endX = cookieJar.x + cookieJar.width / 2f - smallCookie.width / 2f
        val endY = cookieJar.y + cookieJar.height / 2f - smallCookie.height / 2f

        smallCookie.x = startX
        smallCookie.y = startY

        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.4f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.4f)

        val animator = ObjectAnimator.ofPropertyValuesHolder(
            smallCookie,
            scaleX,
            scaleY,
            PropertyValuesHolder.ofFloat(View.X, startX, endX),
            PropertyValuesHolder.ofFloat(View.Y, startY, endY)
        )

        animator.duration = 700
        animator.interpolator = AccelerateDecelerateInterpolator()

        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                smallCookie.visibility = View.GONE
                smallCookie.scaleX = 1f
                smallCookie.scaleY = 1f
            }
        })
        animator.start()
    }
}