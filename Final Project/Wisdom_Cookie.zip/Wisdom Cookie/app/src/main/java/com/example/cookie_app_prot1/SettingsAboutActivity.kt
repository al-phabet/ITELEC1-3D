package com.example.cookie_app_prot1

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.PackageInfoCompat

class SettingsAboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings_about)

        // Set app version dynamically
        val tvVersion = findViewById<TextView>(R.id.tv_version)
        val pInfo = packageManager.getPackageInfo(packageName, 0)
        val version = PackageInfoCompat.getLongVersionCode(pInfo)
        tvVersion.text = "Version: ${pInfo.versionName} (Build $version)"

        // Contact Support
        val btnContact = findViewById<Button>(R.id.btn_contact_support)
        btnContact.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:ianthe.feyre@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "Support Request")
            }
            startActivity(Intent.createChooser(intent, "Contact Support"))
        }

        // Feedback Form (can open mail or web form)
        val btnFeedback = findViewById<Button>(R.id.btn_feedback)
        btnFeedback.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:ianthe.feyre@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "Feedback for Wisdom Cookie App")
            }
            startActivity(Intent.createChooser(intent, "Send Feedback"))
        }

        // Rate the App
        val btnRate = findViewById<Button>(R.id.btn_rate)
        btnRate.setOnClickListener {
            val uri = Uri.parse("market://details?id=$packageName")
            val goToMarket = Intent(Intent.ACTION_VIEW, uri)
            // If Play Store is not installed
            if (goToMarket.resolveActivity(packageManager) != null) {
                startActivity(goToMarket)
            } else {
                // Open in browser
                val webUri = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                startActivity(Intent(Intent.ACTION_VIEW, webUri))
            }
        }
    }
}
