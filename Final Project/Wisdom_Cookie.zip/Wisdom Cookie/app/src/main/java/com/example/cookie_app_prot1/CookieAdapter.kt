package com.example.cookie_app_prot1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.content.Intent

class CookieAdapter(
    private val quotes: MutableList<String>,
    private val copyClick: (String) -> Unit
) : RecyclerView.Adapter<CookieAdapter.CookieViewHolder>() {

    class CookieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val quoteText: TextView = view.findViewById(R.id.quoteText)
        val shareBtn: ImageButton = view.findViewById(R.id.shareBtn)
        val copyBtn: ImageButton = view.findViewById(R.id.copyBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CookieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cookie_quote, parent, false)
        return CookieViewHolder(view)
    }

    override fun onBindViewHolder(holder: CookieViewHolder, position: Int) {
        val quote = quotes[position]
        holder.quoteText.text = quote

        // Copy quote
        holder.copyBtn.setOnClickListener { copyClick(quote) }

        // Share quote
        holder.shareBtn.setOnClickListener {
            val intent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, quote)
                type = "text/plain"
            }
            holder.itemView.context.startActivity(Intent.createChooser(intent, "Share via"))
        }

    }

    override fun getItemCount(): Int = quotes.size
}
